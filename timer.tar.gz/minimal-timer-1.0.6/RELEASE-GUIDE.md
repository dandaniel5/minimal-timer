# 🚀 Quick Release Guide

## Первый раз (Setup)

### 1. Установи инструменты для публикации
```bash
pip3 install twine setuptools wheel
```

### 2. Зарегистрируйся на PyPI
- Перейди на https://pypi.org/account/register/
- Создай аккаунт
- Подтверди email

### 3. Создай API токен
- Зайди на https://pypi.org/manage/account/token/
- Нажми "Add API token"
- Имя: "minimal-timer"
- Scope: "Entire account" (или конкретный проект)
- Скопируй токен (начинается с `pypi-`)

### 4. Настрой credentials
```bash
cat > ~/.pypirc <<EOF
[pypi]
username = __token__
password = pypi-YOUR-TOKEN-HERE
EOF

chmod 600 ~/.pypirc
```

---

## Каждый релиз

### Простой способ (рекомендуется):
```bash
cd /Users/danilkodolov/Documents/PROJECTS/timer
./release.sh
```

Выбери:
- **1** - если просто хочешь опубликовать текущую версию
- **2** - если хочешь обновить версию и опубликовать

### Что происходит автоматически:
1. ✅ Обновляет версию во всех файлах (если выбрал 2)
2. ✅ Создает git commit и tag
3. ✅ Собирает Python пакет
4. ✅ Публикует в PyPI
5. ✅ Обновляет Homebrew formula
6. ✅ Показывает что делать дальше

### После скрипта:
```bash
# Запушь изменения в GitHub
git push && git push --tags

# Создай GitHub Release
# Перейди на: https://github.com/dandaniel5/minimal-timer/releases/new
# Выбери созданный tag (v1.0.1)
# Добавь описание изменений
# Нажми "Publish release"
```

---

## Проверка

### Проверь что всё работает:
```bash
# Установи из PyPI
pip3 install minimal-timer --upgrade

# Запусти
timer 5m -n "Test"

# Проверь версию
pip3 show minimal-timer
```

---

## Troubleshooting

### Ошибка: "twine not found"
```bash
pip3 install twine
```

### Ошибка: "Invalid credentials"
```bash
# Проверь ~/.pypirc
cat ~/.pypirc

# Пересоздай токен на https://pypi.org/manage/account/token/
```

### Ошибка: "Package already exists"
```bash
# Это нормально при обновлении
# Скрипт использует --skip-existing
```

### Хочу только обновить версию без публикации
```bash
./update-all.sh
```

### Хочу только опубликовать без обновления версии
```bash
./release.sh
# Выбери опцию 1
```

---

## Быстрая шпаргалка

```bash
# Полный релиз (обновить версию + опубликовать)
./release.sh  # выбери 2, введи версию

# Запушить в GitHub
git push && git push --tags

# Готово! Теперь можно установить:
pip install minimal-timer
```

---

## Версионирование

Используй семантическое версионирование (MAJOR.MINOR.PATCH):

- **1.0.0 → 1.0.1** - исправление багов
- **1.0.1 → 1.1.0** - новые фичи (обратно совместимые)
- **1.1.0 → 2.0.0** - breaking changes

Примеры:
- Исправил баг → `1.0.1`
- Добавил новый флаг `-v` → `1.1.0`
- Изменил формат вывода → `2.0.0`
